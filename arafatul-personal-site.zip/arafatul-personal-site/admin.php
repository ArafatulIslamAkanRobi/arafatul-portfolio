<?php
session_start(); require __DIR__.'/db.php'; $cfg=require __DIR__.'/config.php';
$error=''; $notice='';
if(isset($_GET['logout'])) { session_destroy(); header('Location: admin.php'); exit; }
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['login'])) {
  if(!empty($cfg['admin_password_hash']) && password_verify($_POST['password']??'', $cfg['admin_password_hash'])) { session_regenerate_id(true); $_SESSION['admin']=true; csrf_token(); header('Location: admin.php'); exit; }
  $error='লগইন ব্যর্থ হয়েছে। config.php-তে সঠিক password hash বসানো আছে কি না দেখুন।';
}
if(!empty($_SESSION['admin']) && $_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['save_content'])) {
  if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')) { http_response_code(403); exit('Invalid CSRF token'); }
  $json=$_POST['content_json']??''; $data=json_decode($json,true);
  if(!is_array($data)) $error='JSON সঠিক নয়: '.$jsonError=(json_last_error_msg());
  else { $pdo->prepare('INSERT INTO site_content(content_key,content_json) VALUES(?,?) ON DUPLICATE KEY UPDATE content_json=VALUES(content_json)')->execute(['main',json_encode($data,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)]); $notice='পরিবর্তন সংরক্ষিত হয়েছে। ওয়েবসাইট দেখুন।'; }
}
if(!empty($_SESSION['admin']) && $_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['upload_image'])) {
  if(!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??'')) { http_response_code(403); exit('Invalid CSRF token'); }
  if(empty($_FILES['image']['tmp_name']) || $_FILES['image']['error']!==UPLOAD_ERR_OK) $error='ছবি আপলোড করা যায়নি।';
  else {
    $f=$_FILES['image']; $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']); $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
    if(!isset($allowed[$mime]) || $f['size']>8*1024*1024) $error='শুধু JPG, PNG, WEBP বা GIF; সর্বোচ্চ ৮ MB।';
    else { if(!is_dir(__DIR__.'/uploads')) mkdir(__DIR__.'/uploads',0755,true); $name='img_'.bin2hex(random_bytes(8)).'.'.$allowed[$mime]; if(move_uploaded_file($f['tmp_name'],__DIR__.'/uploads/'.$name)) $notice='আপলোড সফল: uploads/'.$name.' — এই পথটি JSON-এর image বা profile_image ফিল্ডে বসান।'; else $error='ফাইল সংরক্ষণ ব্যর্থ।'; }
  }
}
$logged=!empty($_SESSION['admin']); $data=$logged?load_content($pdo):[];
?><!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin — Arafatul</title><link rel="stylesheet" href="assets/style.css"><style>.admin-wrap{max-width:1000px;margin:50px auto;padding:20px}.editor{width:100%;min-height:540px;font:14px/1.6 ui-monospace,monospace;padding:16px;border:1px solid #ccd4ce;border-radius:12px}.field{display:block;margin:12px 0}.field input{padding:12px;width:100%;max-width:420px}.notice{padding:12px;background:#e3f5e8;border-radius:8px;margin:12px 0}.error{padding:12px;background:#ffe8e8;border-radius:8px;margin:12px 0}.adminbar{display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap}</style></head><body><div class="admin-wrap"><div class="adminbar"><a class="brand" href="index.php">ARAFATUL<span>.</span> ADMIN</a><?php if($logged):?><a href="admin.php?logout=1">Logout</a><?php endif;?></div><h1>ওয়েবসাইট কন্ট্রোল প্যানেল</h1><p>এখান থেকে পেজের লেখা, সেবা, প্রজেক্ট, অভিজ্ঞতা, ব্লগ, অর্জন, স্মৃতি ও ছবির পথ পরিবর্তন করা যাবে।</p><?php if($notice):?><div class="notice"><?=esc($notice)?></div><?php endif;?><?php if($error):?><div class="error"><?=esc($error)?></div><?php endif;?>
<?php if(!$logged):?><form method="post" class="card"><h2>Admin Login</h2><label class="field">পাসওয়ার্ড<input type="password" name="password" required autocomplete="current-password"></label><button class="button primary" name="login" value="1">লগইন</button></form><p class="muted">প্রথমে config.php তৈরি করে admin_password_hash সেট করুন।</p><?php else:?>
<form method="post"><input type="hidden" name="csrf" value="<?=esc(csrf_token())?>"><h2>সব পেজের কনটেন্ট (JSON)</h2><p class="muted">সেভ করার আগে JSON-এর কমা, উদ্ধৃতি ও বন্ধনী ঠিক আছে কি না যাচাই হবে। একটি ব্যাকআপ কপি রেখে সম্পাদনা করুন।</p><textarea class="editor" name="content_json" spellcheck="false"><?=esc(json_encode($data,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES))?></textarea><p><button class="button primary" name="save_content" value="1">সব পরিবর্তন সংরক্ষণ</button> <a class="button ghost" href="index.php" target="_blank">সাইট দেখুন ↗</a></p></form><hr><h2>ছবি আপলোড</h2><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?=esc(csrf_token())?>"><label class="field">ছবি নির্বাচন করুন <input type="file" name="image" accept="image/jpeg,image/png,image/webp,image/gif" required></label><button class="button primary" name="upload_image" value="1">ছবি আপলোড</button></form><p class="muted">ছবি আপলোডের পর পাওয়া uploads/filename পথটি কনটেন্ট JSON-এর profile_image অথবা কোনো item-এর image ফিল্ডে বসাতে হবে।</p><?php endif;?></div></body></html>
