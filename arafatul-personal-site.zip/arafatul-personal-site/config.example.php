<?php
// Copy this file to config.php and fill in your database credentials.
return [
  'db_host' => 'localhost',
  'db_name' => 'arafatul_site',
  'db_user' => 'YOUR_DB_USER',
  'db_pass' => 'YOUR_DB_PASSWORD',
  // Generate with: php -r "echo password_hash('YOUR-STRONG-PASSWORD', PASSWORD_DEFAULT), PHP_EOL;"
  'admin_password_hash' => 'REPLACE_WITH_PASSWORD_HASH',
  'site_name' => 'Arafatul Islam Akan Robi',
];
