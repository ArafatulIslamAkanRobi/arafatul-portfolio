<?php
$configFile = __DIR__ . '/config.php';
if (!file_exists($configFile)) { http_response_code(500); exit('Setup required: copy config.example.php to config.php and configure the database.'); }
$config = require $configFile;
try {
  $pdo = new PDO('mysql:host='.$config['db_host'].';dbname='.$config['db_name'].';charset=utf8mb4', $config['db_user'], $config['db_pass'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
} catch (Throwable $e) { http_response_code(500); exit('Database connection failed. Check config.php and schema.sql.'); }
function esc($s) { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function load_content($pdo) {
  $q=$pdo->prepare('SELECT content_json FROM site_content WHERE content_key=?'); $q->execute(['main']); $raw=$q->fetchColumn();
  if ($raw) { $data=json_decode($raw,true); if (is_array($data)) return $data; }
  $sample=json_decode(file_get_contents(__DIR__.'/content.example.json'),true);
  $pdo->prepare('INSERT INTO site_content(content_key,content_json) VALUES(?,?) ON DUPLICATE KEY UPDATE content_json=VALUES(content_json)')->execute(['main',json_encode($sample,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)]);
  return $sample;
}
function csrf_token() { if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function require_admin() { if (empty($_SESSION['admin'])) { header('Location: admin.php'); exit; } }
