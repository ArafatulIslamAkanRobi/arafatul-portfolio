# Arafatul Islam Akan Robi — Personal Website Starter

A responsive PHP + MySQL starter site with a protected admin login and editable JSON content. It includes Home, About, Services, Portfolio, Experience & Contributions, Blog, Achievements, Pages of Memories, Contact and image upload.

## Requirements
- PHP 8.1+ with PDO MySQL, Fileinfo and file uploads enabled
- MySQL/MariaDB
- HTTPS in production

## Installation (shared hosting / cPanel)
1. Create a MySQL database and database user in cPanel; grant the user access to the database.
2. Import `schema.sql` using phpMyAdmin.
3. Copy `config.example.php` to `config.php` and set database credentials.
4. Generate a password hash on a trusted PHP command line:
   `php -r "echo password_hash('YOUR-STRONG-PASSWORD', PASSWORD_DEFAULT), PHP_EOL;"`
   Put the resulting hash in `admin_password_hash` in `config.php`. Never use the plain password as the hash.
5. Upload the folder contents to your hosting document root (or a subfolder). Ensure `uploads/` is writable by PHP but not executable. Keep `config.php` protected from public access using server configuration.
6. Visit `admin.php`, log in, edit the JSON content and save. Use the image uploader and then set the returned `uploads/...` path in `profile_image` or an item's `image` field.
7. Visit `index.php` to see the public website.

## Content editing
The admin editor stores all editable page content in the `site_content` table as JSON. Keep a backup before editing. Valid arrays: `services`, `projects`, `experiences`, `achievements`, `blog_posts`, `memories`, `socials`.

Example memory: `{"title":"A special day","date":"2026-10-24","story":"The story...","image":"uploads/example.jpg","visibility":"public"}`. Use `visibility: "private"` for a private memory. Private memories are omitted from the public homepage; a full private memory library with owner login, edit/delete UI, signed media URLs, people albums and diary CRUD is a separate production feature and is NOT implemented in this starter.

## Security / production notes
- Change the default setup values before deployment; use a strong unique admin password and HTTPS.
- Protect `config.php` and prevent script execution inside `uploads/` at the web-server level.
- Restrict admin access further (MFA/IP controls if available), set upload size limits, and configure server backups.
- This starter has a basic single-admin login and CSRF tokens. It is not a security-audited production CMS. Before storing sensitive personal diaries/photos, implement a dedicated private memory module with authorization checks on every request, private object storage, short-lived signed URLs, rate limiting, audit logging, and tested backups.
- No live hosting or database is included; deploy to your own hosting and database.
